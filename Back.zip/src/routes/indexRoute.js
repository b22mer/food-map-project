module.exports = function (app) {
  const index = require("../controllers/indexController");
  const jwtMiddleware = require("../../config/jwtMiddleware");

  //----------------------------
  app.get("/restaurants", index.readRestaurants);
  app.patch("/restaurants", index.searchRestaurants);

};
