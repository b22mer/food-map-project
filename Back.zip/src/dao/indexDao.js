const { pool } = require("../../config/database");

//검색요청으로 인한
exports.searchRestaurants = async function (connection, title) {
  const selectRestaurantsQuery = `select title, address, category, infoUrl, review, phone from Restaurants where status="D"`;
  const selectRestaurantsByTitleQuery = `select * from Restaurants where title = ? and status="A";`;
  const selectRestaurantsParams = [title];
  const rows = await connection.query(
    title ? selectRestaurantsByTitleQuery : selectRestaurantsQuery,
    // selectRestaurantsByCategoryQuery,
    selectRestaurantsParams
  );

  return rows;

};

//클릭으로 인한
exports.selectRestaurants = async function (connection, category) {
  const selectAllRestaurantsQuery = `SELECT title, address, category, infoUrl, review, phone FROM Restaurants where status = 'A';`;
  const selectCategorizedRestaurantsQuery = `SELECT * FROM Restaurants where status = 'A' and category = ?;`;
  const Params = [category];

  const Query = category
    ? selectCategorizedRestaurantsQuery
    : selectAllRestaurantsQuery;

  const rows = await connection.query(Query, Params);



  return rows;

};

  // const selectRestaurantsQuery = `select title, address, category, videoUrl from Restaurants where status="A"`;
  // const selectRestaurantsByCategoryQuery = `select * from Restaurants where category = ? and status="A";`;
  // const selectRestaurantsParams = [category];
  // const rows = await connection.query(
  //   category ? selectRestaurantsByCategoryQuery : selectRestaurantsQuery,
  //   // selectRestaurantsByCategoryQuery,
  //   selectRestaurantsParams
  // );











