const express = require("express");
const compression = require("compression");
const methodOverride = require("method-override");
var cors = require("cors");

module.exports = function () {
  const app = express();

  // 미들웨어 설정  
  app.use(compression()); //HTTP 요청을 압축 및 해제
  app.use(express.json()); // 바디 값을 파싱
  app.use(express.urlencoded({ extended: true })); //FORM으로 제출되는 값 파싱
  app.use(methodOverride()); // PUT, DELETE 요청처리
  app.use(cors()); // 웹브라우저 CORS 설정관리
  // app.use(express.static("/home/ubuntu/food-map/front"));

  // app.use(express.static(process.cwd() + '/public'));

  // 직접 구현해야하는 모듈
  //DAO: DATA ACCESS OBJ
  require("../src/routes/indexRoute")(app);

  return app;
};
