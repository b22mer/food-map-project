module.exports= { // 깃허브에 올라가지 않도록
  jwtsecret: "jwt_secret_key_9312",  
  host: "3.38.25.13", // 외부접속 주소
  user: "root",
  port: "3306",
  password: "0000",
  database: "FoodMap", // 접속할 스키마를 입력
};